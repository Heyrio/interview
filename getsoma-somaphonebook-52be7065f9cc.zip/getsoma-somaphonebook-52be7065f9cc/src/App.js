import PhoneBook from './Views/PhoneBook';

function App() {
  return (
    <div className="App">
      <PhoneBook/>
    </div>
  );
}

export default App;
