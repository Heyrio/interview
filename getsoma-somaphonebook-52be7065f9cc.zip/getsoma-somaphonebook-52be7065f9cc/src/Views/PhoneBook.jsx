import React, {useState} from 'react';

const PhoneBook = (props) => {

    const [contacts, setContacts] = useState([])

return (
        <div>
            <p>Phone book view</p>
        </div>
    );
}

export default PhoneBook;
