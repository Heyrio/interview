# SOMA Phone book Challenge  

Hey there applicant!

Thanks for taking the time to complete this assessment! This repo contains a skeleton React project.  

Your task is to modify the code so that the page contains a very simple SOMA Phone Book that allows a 911 dispatcher to enter and access   non-emergency phone numbers. example: Animal services & wild life.  

1.) Users should be able to enter a person's name and phone number into a modal.

2.) When you click the add button on that modal that contact should be added to a contact list.

2.) Users should be able to add and delete non-emergency contacts from the list.  

You will be scored on the following:  

Is the code simple and well written?  
Is all requested functionality present?  
Is your code using idiomatic React techniques and component decomposition?  
Does your code demonstrated proficiency in modern CSS layouts, such as Flexbox and Grid?  

## Bonus points:  

Write a few tests for your code.
## Notes:  

While you are working through this challenge, please verbally walk us through your thought process as you are building the project.  

Good Luck!  